/*
  El Niño Farm Advisor - ESP32 field node (reference sketch)

  Reads a capacitive soil moisture sensor + a DHT11 temperature sensor and
  serves the readings as JSON over Wi-Fi:

      GET http://<esp32-ip>/data   ->   {"soil_moisture": 31.4, "temperature": 33.8}

  Wiring (adjust to your hardware):
      Soil moisture sensor AOUT -> GPIO 34 (ADC1)
      DHT11 DATA                -> GPIO 4
      Sensors VCC -> 3V3, GND -> GND

  Libraries (Arduino IDE -> Library Manager): "DHT sensor library" (Adafruit),
  "Adafruit Unified Sensor".

  CALIBRATE: put the soil sensor in dry air and note the ADC value (DRY_ADC),
  then in a glass of water (WET_ADC), and update the two constants below.
*/

#include <WiFi.h>
#include <WebServer.h>
#include <DHT.h>

const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASS = "YOUR_WIFI_PASSWORD";

const int SOIL_PIN = 34;
const int DHT_PIN = 4;
const int DRY_ADC = 3200;   // reading in dry air
const int WET_ADC = 1400;   // reading in water

DHT dht(DHT_PIN, DHT11);
WebServer server(80);

float readSoilPercent() {
  long sum = 0;
  for (int i = 0; i < 10; i++) { sum += analogRead(SOIL_PIN); delay(5); }
  float raw = sum / 10.0;
  float pct = (DRY_ADC - raw) * 100.0 / (DRY_ADC - WET_ADC);
  return constrain(pct, 0.0, 100.0);
}

void handleData() {
  float soil = readSoilPercent();
  float temp = dht.readTemperature();
  if (isnan(temp)) temp = 0;
  String json = "{\"soil_moisture\":" + String(soil, 1) +
                ",\"temperature\":" + String(temp, 1) + "}";
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", json);
}

void setup() {
  Serial.begin(115200);
  dht.begin();
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("Connecting");
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.print("\nConnected. Open: http://");
  Serial.print(WiFi.localIP());
  Serial.println("/data");
  server.on("/data", handleData);
  server.begin();
}

void loop() {
  server.handleClient();
}
