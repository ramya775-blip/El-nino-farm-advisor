# Prototype screen recording script (about 3 minutes)

**Before you hit record**
- `streamlit run app.py` is already running, browser zoomed to ~110%, notifications off.
- Start in **Demo (sliders)** mode with soil 28%, temperature 34 °C. Rain override off.
- Do one dry run. Keep the recording under 4 minutes.

---

### 0:00 – Problem (15 s)
> "Farmers today face delayed monsoons, long dry spells and sudden heavy rain. Without real-time field and weather data, irrigation and sowing become guesswork. We built El Niño Farm Advisor to turn that data into simple decisions."

*Show: the dashboard title.*

### 0:15 – Architecture (20 s)
> "Soil moisture and temperature sensors feed an ESP32. Our Python app combines that with a live rain and temperature forecast and runs a decision engine that produces alerts."

*Show: the README architecture diagram on GitHub, or the project folder.*

### 0:35 – Dry soil, no rain (40 s)
Soil 28%, temp 34 °C.
> "Soil moisture is 28%, rain probability is low. The advisor says **Irrigate Now** and shows an irrigation alert, with the reason. Sowing is not recommended because the soil is too dry for germination."

### 1:15 – Rain expected (40 s)
Tick **Override rain probability**, set 80%.
> "Same dry soil, but rain is now likely. The advisor switches to **Delay Irrigation** and raises a rain alert. That is water saved."

### 1:55 – Good sowing window (30 s)
Untick override. Soil 55%, temp 28 °C.
> "With healthy moisture, a comfortable temperature and no heavy rain coming, it shows **Suitable Sowing Window**."

### 2:25 – Heat alert (15 s)
Temp 41 °C.
> "If temperature crosses the threshold, a heat alert advises irrigating in the early morning or evening."

### 2:40 – Live sensor mode (20 s)
Switch to **Simulated live feed** (or **ESP32 (Wi-Fi)** if hardware is connected).
> "In live mode the readings stream in and the decisions update automatically."

*Show: the live soil moisture chart moving, plus the forecast charts.*

### 3:00 – Close (10 s)
> "Less guesswork. Smarter irrigation. More resilient farming. Thank you."

---

**Recording tips**
- Windows: `Win + G` (Xbox Game Bar) or OBS Studio. Mac: `Cmd + Shift + 5`. Phone-to-laptop is not needed.
- Record the browser window only, 1080p if possible.
- If sound is not allowed, add the lines above as captions or a short title card.
- Export as MP4, then upload to Google Drive or YouTube (unlisted) and make sure the link is accessible to anyone with the link.
