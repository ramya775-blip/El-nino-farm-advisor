# 🌾 El Niño Farm Advisor

**Turning unpredictable weather into actionable farming decisions.**

Built for **YUKTHI 2026**. El Niño Farm Advisor combines low-cost IoT field sensors, weather forecast data and a Python decision engine to tell a farmer, in plain language, **when to irrigate, when to hold off, and whether it is a good time to sow**.

> We do **not** predict El Niño. We help farmers adapt to the changing field and weather conditions it causes.

## The problem

Delayed monsoons, long dry spells and sudden heavy rain make farming a guessing game. Farmers lack real-time, localized field and weather intelligence, which leads to badly timed irrigation, wasted water and difficult sowing decisions.

## How it works

```
 Soil Moisture Sensor ─┐
                       ├─> ESP32 ──Wi-Fi──> Python Decision Engine ──> Dashboard + Alerts
 Temperature Sensor ───┘                          ^
                                                  │
                                    Weather API (Open-Meteo forecast)
```

1. **Field sensing** – an ESP32 reads soil moisture and temperature and serves them as JSON over Wi-Fi.
2. **Weather intelligence** – the app fetches a 6-day rain and temperature forecast from the free [Open-Meteo](https://open-meteo.com/) API (no API key needed).
3. **Decision engine** – rule-based logic fuses both data sources into recommendations that can be explained to a farmer.
4. **Farmer alerts** – a Streamlit dashboard shows irrigation, rain, sowing and heat alerts.

## Decision rules

| Situation | Recommendation |
|---|---|
| Soil moisture < 35% and rain chance < 60% | **Irrigate Now** + irrigation alert |
| Soil moisture < 35% and rain chance ≥ 60% | **Delay Irrigation** + rain alert |
| Soil moisture 35–70% | No irrigation needed |
| Soil moisture > 70% | No irrigation needed (soil saturated) |
| Soil 40–75%, temp 18–35 °C, rain risk ≤ 70% over 3 days | **Suitable Sowing Window** |
| Any sowing condition out of range | Sowing **not recommended**, with the reasons listed |
| Temperature or 3-day forecast ≥ 38 °C | Heat alert (irrigate early morning or evening) |

All thresholds live in `Thresholds` in `decision_engine.py` and can be changed live from the dashboard sidebar.

## Features

- Live dashboard with soil moisture, temperature, rain probability, irrigation and sowing status
- Four alert types: irrigation, rain, sowing, heat
- Three sensor modes: **Demo sliders** (to show how decisions change), **Simulated live feed**, **ESP32 over Wi-Fi**
- Real weather forecast with an automatic offline fallback so the demo never crashes
- Every recommendation comes with a plain-language reason
- Unit-tested decision engine

## Quick start

```bash
git clone https://github.com/<your-username>/el-nino-farm-advisor.git
cd el-nino-farm-advisor
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

The dashboard opens at http://localhost:8501. Pick a sensor source in the sidebar:

- **Demo (sliders)** – drag soil moisture and temperature to see decisions change instantly. Tick *Override rain probability* to show the "rain expected, delay irrigation" case.
- **Simulated live feed** – a field that slowly dries out, refreshing every 2 seconds.
- **ESP32 (Wi-Fi)** – paste your ESP32's address, e.g. `http://192.168.1.50/data`.

## Hardware setup (ESP32)

Reference sketch: [`esp32/farm_sensor/farm_sensor.ino`](esp32/farm_sensor/farm_sensor.ino)

| Component | ESP32 pin |
|---|---|
| Capacitive soil moisture sensor (AOUT) | GPIO 34 |
| DHT11 temperature sensor (DATA) | GPIO 4 |
| Sensor power | 3V3 and GND |

1. Install the **DHT sensor library** and **Adafruit Unified Sensor** in the Arduino IDE.
2. Set `WIFI_SSID` and `WIFI_PASS` in the sketch.
3. Calibrate `DRY_ADC` (sensor in air) and `WET_ADC` (sensor in water).
4. Upload, open the Serial Monitor, and note the printed IP address.
5. Enter `http://<that-ip>/data` in the dashboard.

The ESP32 and the computer running the dashboard must be on the same Wi-Fi network.

## Project structure

```
app.py                Streamlit dashboard
decision_engine.py    Rule-based irrigation / sowing / alert logic
weather.py            Open-Meteo forecast client with offline fallback
sensors.py            Simulated sensor + ESP32 HTTP reader
esp32/                ESP32 Arduino sketch
tests/                Unit tests for the decision engine
docs/DEMO_SCRIPT.md   Script for the prototype screen recording
```

## Run the tests

```bash
pytest
```

## Team

**YUKTHI 2026 team**

- Nafisa (Team Lead)
- Varshini Yarramsetty
- Gayathri Marasani
- Ramyasree Bai
- Poojitha

## Future scope

- Automatic pump control
- Mobile app with regional-language alerts
- Crop-specific AI recommendations
- Solar-powered sensors
- Multi-farm monitoring
- AI-based crop risk prediction
