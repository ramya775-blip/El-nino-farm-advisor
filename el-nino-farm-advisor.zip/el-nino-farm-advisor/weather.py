"""Weather intelligence: forecast from the free Open-Meteo API (no API key).

If the network is down (common at hackathon venues), we fall back to clearly
labelled sample data so the dashboard never crashes during a demo.
"""

from datetime import date, timedelta
from typing import Dict, List, Tuple

import requests

API_URL = "https://api.open-meteo.com/v1/forecast"


def _sample_forecast(days: int) -> List[Dict]:
    temps = [34, 35, 33, 31, 30, 32, 33]
    rain = [10, 20, 55, 80, 65, 30, 15]
    mm = [0.0, 0.5, 4.0, 18.0, 9.0, 1.0, 0.0]
    out = []
    for i in range(days):
        out.append({
            "date": (date.today() + timedelta(days=i)).isoformat(),
            "temp_max": float(temps[i % len(temps)]),
            "rain_prob": float(rain[i % len(rain)]),
            "rain_mm": float(mm[i % len(mm)]),
        })
    return out


def fetch_forecast(lat: float, lon: float, days: int = 6) -> Tuple[List[Dict], str]:
    """Return (daily_forecast, source_label)."""
    params = {
        "latitude": lat,
        "longitude": lon,
        "daily": "temperature_2m_max,precipitation_probability_max,precipitation_sum",
        "timezone": "auto",
        "forecast_days": days,
    }
    try:
        r = requests.get(API_URL, params=params, timeout=8)
        r.raise_for_status()
        d = r.json()["daily"]
        out = []
        for i, day in enumerate(d["time"]):
            out.append({
                "date": day,
                "temp_max": float(d["temperature_2m_max"][i] or 0),
                "rain_prob": float(d["precipitation_probability_max"][i] or 0),
                "rain_mm": float(d["precipitation_sum"][i] or 0),
            })
        return out, "Open-Meteo (live forecast)"
    except Exception:
        return _sample_forecast(days), "Offline sample data (no internet)"
