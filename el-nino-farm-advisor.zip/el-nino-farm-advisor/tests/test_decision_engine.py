"""Unit tests for the decision engine.

Run with either:
    pytest
    python tests/test_decision_engine.py
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from decision_engine import decide  # noqa: E402


def kinds(decision):
    return {a.kind for a in decision.alerts}


def test_deck_example_dry_soil_low_rain():
    """Slide 7 of the pitch deck: 28% soil, 34C, 10% rain."""
    d = decide(soil_moisture=28, temperature=34, rain_prob=10)
    assert d.irrigation_status == "REQUIRED"
    assert d.irrigation_action == "Irrigate Now"
    assert d.sowing_status == "NOT RECOMMENDED"
    assert "irrigation" in kinds(d)


def test_dry_soil_but_rain_expected_delays_irrigation():
    d = decide(soil_moisture=25, temperature=30, rain_prob=80)
    assert d.irrigation_status == "DELAY"
    assert d.irrigation_action == "Delay Irrigation"
    assert "rain" in kinds(d)
    assert "irrigation" not in kinds(d)


def test_adequate_moisture_needs_no_irrigation():
    d = decide(soil_moisture=55, temperature=28, rain_prob=10)
    assert d.irrigation_status == "NOT NEEDED"


def test_saturated_soil_needs_no_irrigation():
    d = decide(soil_moisture=85, temperature=28, rain_prob=10)
    assert d.irrigation_status == "NOT NEEDED"
    assert d.sowing_status == "NOT RECOMMENDED"  # waterlogged


def test_good_sowing_window():
    d = decide(soil_moisture=55, temperature=28, rain_prob=20, rain_prob_3day=30)
    assert d.sowing_status == "SUITABLE"
    assert d.sowing_action == "Suitable Sowing Window"
    assert "sowing" in kinds(d)


def test_heavy_rain_ahead_blocks_sowing():
    d = decide(soil_moisture=55, temperature=28, rain_prob=20, rain_prob_3day=85)
    assert d.sowing_status == "NOT RECOMMENDED"
    assert any("rain" in r.lower() for r in d.sowing_reasons)


def test_heat_alert_from_current_temperature():
    d = decide(soil_moisture=50, temperature=41, rain_prob=5)
    assert "heat" in kinds(d)


def test_heat_alert_from_forecast():
    d = decide(soil_moisture=50, temperature=30, rain_prob=5, forecast_max_temp=40)
    assert "heat" in kinds(d)


def test_all_clear_when_nothing_to_report():
    # Soil moisture in the middle band but too cold to sow, no rain, no heat.
    d = decide(soil_moisture=50, temperature=15, rain_prob=5)
    assert kinds(d) == {"ok"}


def test_every_decision_has_at_least_one_alert():
    for soil in (0, 30, 50, 90):
        for temp in (10, 30, 45):
            for rain in (0, 50, 90):
                assert decide(soil, temp, rain).alerts


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in tests:
        fn()
        print(f"PASS  {fn.__name__}")
    print(f"\n{len(tests)} tests passed")
