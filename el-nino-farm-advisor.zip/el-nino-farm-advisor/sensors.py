"""Field sensing layer.

Two ways to get soil moisture + temperature into the dashboard:

1. SimulatedSensor -- a realistic drifting feed so the prototype can be demoed
   without hardware.
2. read_esp32()    -- reads JSON from the ESP32 over Wi-Fi
   (see esp32/farm_sensor/farm_sensor.ino).  Expected payload:
       {"soil_moisture": 31.4, "temperature": 33.8}
"""

import random
from typing import Dict

import requests


class SimulatedSensor:
    """Slowly drying field with random noise and occasional 'irrigation' jumps."""

    def __init__(self, soil: float = 45.0, temp: float = 32.0, seed: int = None):
        self.soil = soil
        self.temp = temp
        self.rng = random.Random(seed)

    def step(self) -> Dict[str, float]:
        self.soil += self.rng.uniform(-2.5, 0.5)       # drifts dry
        if self.soil < 12:                              # farmer waters the field
            self.soil = self.rng.uniform(55, 70)
        self.soil = max(0.0, min(100.0, self.soil))
        self.temp += self.rng.uniform(-0.6, 0.6)
        self.temp = max(15.0, min(46.0, self.temp))
        return {"soil_moisture": round(self.soil, 1), "temperature": round(self.temp, 1)}


def read_esp32(url: str, timeout: float = 4.0) -> Dict[str, float]:
    """Fetch one reading from the ESP32's HTTP endpoint."""
    r = requests.get(url, timeout=timeout)
    r.raise_for_status()
    d = r.json()
    return {
        "soil_moisture": float(d["soil_moisture"]),
        "temperature": float(d["temperature"]),
    }
