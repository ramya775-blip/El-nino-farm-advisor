"""Decision engine for El Niño Farm Advisor.

Fuses field sensor data (soil moisture, temperature) with weather forecast
data (rain probability) and turns it into simple farming decisions:
irrigation, sowing, rain and heat alerts.

The engine is deliberately rule-based so every recommendation is explainable
to a farmer ("why am I being told to irrigate?").
"""

from dataclasses import dataclass, field
from typing import List


@dataclass
class Thresholds:
    soil_dry: float = 35.0        # % below this the field needs water
    soil_wet: float = 70.0        # % above this the soil is saturated
    rain_likely: float = 60.0     # % rain probability treated as "rain expected"
    heat: float = 38.0            # deg C treated as heat stress
    sow_soil_min: float = 40.0    # % minimum soil moisture for sowing
    sow_soil_max: float = 75.0    # % maximum soil moisture for sowing
    sow_temp_min: float = 18.0    # deg C
    sow_temp_max: float = 35.0    # deg C
    sow_rain_max: float = 70.0    # % heavy rain risk can wash seeds away


@dataclass
class Alert:
    kind: str      # irrigation | rain | sowing | heat | ok
    level: str     # error | warning | success | info
    title: str
    message: str


@dataclass
class Decision:
    irrigation_status: str   # REQUIRED | DELAY | NOT NEEDED
    irrigation_action: str   # Irrigate Now | Delay Irrigation | No Irrigation Needed
    sowing_status: str       # SUITABLE | NOT RECOMMENDED
    sowing_action: str
    irrigation_reason: str
    sowing_reasons: List[str] = field(default_factory=list)
    alerts: List[Alert] = field(default_factory=list)


def decide(
    soil_moisture: float,
    temperature: float,
    rain_prob: float,
    rain_prob_3day: float = None,
    forecast_max_temp: float = None,
    t: Thresholds = None,
) -> Decision:
    """Return a Decision from current sensor + forecast values.

    soil_moisture     -- current soil moisture, percent
    temperature       -- current field temperature, deg C
    rain_prob         -- today's rain probability, percent
    rain_prob_3day    -- highest rain probability over the next 3 days
    forecast_max_temp -- highest forecast temperature in the next few days
    """
    t = t or Thresholds()
    if rain_prob_3day is None:
        rain_prob_3day = rain_prob
    if forecast_max_temp is None:
        forecast_max_temp = temperature

    # ---- Irrigation -------------------------------------------------------
    if soil_moisture < t.soil_dry:
        if rain_prob >= t.rain_likely:
            irr_status, irr_action = "DELAY", "Delay Irrigation"
            irr_reason = (
                f"Soil is dry ({soil_moisture:.0f}%) but rain is likely "
                f"({rain_prob:.0f}%). Wait and save water."
            )
        else:
            irr_status, irr_action = "REQUIRED", "Irrigate Now"
            irr_reason = (
                f"Soil moisture is low ({soil_moisture:.0f}% < {t.soil_dry:.0f}%) "
                f"and rain chance is only {rain_prob:.0f}%."
            )
    elif soil_moisture > t.soil_wet:
        irr_status, irr_action = "NOT NEEDED", "No Irrigation Needed"
        irr_reason = f"Soil is already wet ({soil_moisture:.0f}%). Watering would be wasted."
    else:
        irr_status, irr_action = "NOT NEEDED", "No Irrigation Needed"
        irr_reason = f"Soil moisture is adequate ({soil_moisture:.0f}%)."

    # ---- Sowing -----------------------------------------------------------
    sow_reasons = []
    if soil_moisture < t.sow_soil_min:
        sow_reasons.append(
            f"Soil too dry for germination ({soil_moisture:.0f}% < {t.sow_soil_min:.0f}%)"
        )
    if soil_moisture > t.sow_soil_max:
        sow_reasons.append(
            f"Soil too waterlogged for sowing ({soil_moisture:.0f}% > {t.sow_soil_max:.0f}%)"
        )
    if temperature < t.sow_temp_min:
        sow_reasons.append(f"Too cold for sowing ({temperature:.0f}°C)")
    if temperature > t.sow_temp_max:
        sow_reasons.append(f"Too hot for sowing ({temperature:.0f}°C > {t.sow_temp_max:.0f}°C)")
    if rain_prob_3day > t.sow_rain_max:
        sow_reasons.append(
            f"Heavy rain risk in next 3 days ({rain_prob_3day:.0f}%) may wash seeds away"
        )

    if sow_reasons:
        sow_status, sow_action = "NOT RECOMMENDED", "Wait for a better window"
    else:
        sow_status, sow_action = "SUITABLE", "Suitable Sowing Window"
        sow_reasons.append("Soil moisture, temperature and rain outlook are all in range")

    # ---- Alerts -----------------------------------------------------------
    alerts: List[Alert] = []
    if irr_status == "REQUIRED":
        alerts.append(Alert("irrigation", "error", "IRRIGATION ALERT",
                            "Soil moisture low. Irrigation recommended."))
    if rain_prob >= t.rain_likely or rain_prob_3day >= t.rain_likely:
        alerts.append(Alert("rain", "info", "RAIN ALERT",
                            "Rain expected. Delay irrigation."))
    if sow_status == "SUITABLE":
        alerts.append(Alert("sowing", "success", "SOWING ALERT",
                            "Suitable sowing window. Conditions look good."))
    if temperature >= t.heat or forecast_max_temp >= t.heat:
        alerts.append(Alert("heat", "warning", "HEAT ALERT",
                            f"High temperature ({max(temperature, forecast_max_temp):.0f}°C). "
                            "Irrigate in early morning or evening to reduce evaporation."))
    if not alerts:
        alerts.append(Alert("ok", "info", "ALL CLEAR", "No action needed right now."))

    return Decision(irr_status, irr_action, sow_status, sow_action,
                    irr_reason, sow_reasons, alerts)
