"""El Niño Farm Advisor - Python dashboard.

Run:  streamlit run app.py
"""

import time

import pandas as pd
import streamlit as st

from decision_engine import Thresholds, decide
from sensors import SimulatedSensor, read_esp32
from weather import fetch_forecast

st.set_page_config(page_title="El Niño Farm Advisor", page_icon="🌾", layout="wide")


@st.cache_data(ttl=600, show_spinner=False)
def get_forecast(lat: float, lon: float):
    return fetch_forecast(lat, lon)


# ---------------------------------------------------------------- sidebar
st.sidebar.title("🌾 Farm Advisor")
mode = st.sidebar.radio(
    "Sensor source",
    ["Demo (sliders)", "Simulated live feed", "ESP32 (Wi-Fi)"],
    help="Demo lets you drag values to show how decisions change.",
)

st.sidebar.subheader("Farm location")
lat = st.sidebar.number_input("Latitude", value=17.385, format="%.4f")
lon = st.sidebar.number_input("Longitude", value=78.4867, format="%.4f")

with st.sidebar.expander("Decision thresholds"):
    th = Thresholds(
        soil_dry=st.slider("Soil dry below (%)", 10, 60, 35),
        soil_wet=st.slider("Soil wet above (%)", 50, 95, 70),
        rain_likely=st.slider("Rain expected at (%)", 30, 90, 60),
        heat=st.slider("Heat alert at (°C)", 30, 45, 38),
    )

forecast, source = get_forecast(lat, lon)
today = forecast[0]
rain_prob = today["rain_prob"]

# ------------------------------------------------------------ sensor input
live = False
if mode == "Demo (sliders)":
    soil = st.sidebar.slider("Soil moisture (%)", 0, 100, 28)
    temp = st.sidebar.slider("Temperature (°C)", 10, 48, 34)
    if st.sidebar.checkbox("Override rain probability", value=False):
        rain_prob = float(st.sidebar.slider("Rain probability (%)", 0, 100, 10))
elif mode == "Simulated live feed":
    live = True
    if "sim" not in st.session_state:
        st.session_state.sim = SimulatedSensor(soil=45, temp=32)
    reading = st.session_state.sim.step()
    soil, temp = reading["soil_moisture"], reading["temperature"]
else:
    live = True
    url = st.sidebar.text_input("ESP32 URL", "http://192.168.1.50/data")
    try:
        reading = read_esp32(url)
        soil, temp = reading["soil_moisture"], reading["temperature"]
    except Exception as e:
        st.error(f"Could not reach the ESP32 at {url}. Check Wi-Fi / IP. ({e})")
        st.stop()

# rolling readings for the live charts
hist = st.session_state.setdefault("hist", [])
hist.append({"time": pd.Timestamp.now(), "soil": soil, "temp": temp})
del hist[:-60]

next3 = forecast[:3]
decision = decide(
    soil_moisture=soil,
    temperature=temp,
    rain_prob=rain_prob,
    rain_prob_3day=max(d["rain_prob"] for d in next3),
    forecast_max_temp=max(d["temp_max"] for d in next3),
    t=th,
)

# ------------------------------------------------------------------ header
st.title("🌾 El Niño Farm Advisor")
st.caption("Turning unpredictable weather into actionable farming decisions. "
           "IoT sensors + weather intelligence + Python decision support.")

# ------------------------------------------------------------------ alerts
for a in decision.alerts:
    text = f"**{a.title}**  \n{a.message}"
    {"error": st.error, "warning": st.warning,
     "success": st.success, "info": st.info}[a.level](text, icon={
        "irrigation": "💧", "rain": "🌧️", "sowing": "🌱", "heat": "🔥", "ok": "✅"}[a.kind])

# ----------------------------------------------------------------- metrics
c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Soil Moisture", f"{soil:.0f}%")
c2.metric("Temperature", f"{temp:.0f}°C")
c3.metric("Rain Probability", f"{rain_prob:.0f}%")
c4.metric("Irrigation", decision.irrigation_status)
c5.metric("Sowing", decision.sowing_status)

# ------------------------------------------------------- recommendation box
left, right = st.columns(2)
with left:
    st.subheader(f"💧 {decision.irrigation_action}")
    st.write(decision.irrigation_reason)
with right:
    st.subheader(f"🌱 {decision.sowing_action}")
    for r in decision.sowing_reasons:
        st.write(f"- {r}")

# ------------------------------------------------------------------ charts
st.divider()
ch1, ch2, ch3 = st.columns(3)
fdf = pd.DataFrame(forecast)
fdf["day"] = pd.to_datetime(fdf["date"]).dt.strftime("%b %d")
fdf = fdf.set_index("day")

with ch1:
    st.markdown("**Soil Moisture (%) - live readings**")
    h = pd.DataFrame(hist).set_index("time")[["soil"]]
    st.line_chart(h, height=220)
with ch2:
    st.markdown("**Temperature forecast (°C, daily max)**")
    st.line_chart(fdf[["temp_max"]], height=220)
with ch3:
    st.markdown("**Rain forecast (%)**")
    st.bar_chart(fdf[["rain_prob"]], height=220)

st.caption(f"Weather source: {source}  •  Sensor source: {mode}")

# ------------------------------------------------------------ live refresh
if live:
    time.sleep(2)
    st.rerun()
